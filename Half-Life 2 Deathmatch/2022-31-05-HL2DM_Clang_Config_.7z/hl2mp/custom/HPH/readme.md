# HPH HUD

**HPH Version**: 1.8

**HUD Version:** 1.8

This is my HUD that I've nicknamed as Quad Eternal.

## Notable HUD Changes

Ignoring HPH stock settings, and it's game fixes

* White crosshair that changes per weapon (affected by flicking bug)

## HUD Variants

If you want to make a variant of the HUD, copy "Config.ini" to the root folder of where the HPH executable is located. If you're not using the default Steam install location (on the C:\ drive in Program Files (x86)), you'll need to change the install directory, either by editing the .ini or changing it inside HPH.