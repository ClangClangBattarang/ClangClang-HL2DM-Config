These are various scripts I've either made or compiled from other sources.

To add to your config, add the following line to the end of either autoexec.cfg or overrides.cfg (Community Patch preferences) file, whichever is loaded last:

exec player_scripts/<script name>.cfg